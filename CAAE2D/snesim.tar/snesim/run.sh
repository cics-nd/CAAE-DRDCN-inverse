#!/bin/bash
#$ -q long
#$ -pe smp 1
#$ -N snesim         # Specify job name
module load matlab
date
./snesim<snesim.par
#matlab -nodesktop -nosplash < run_snesim.m > & out.txt
date
