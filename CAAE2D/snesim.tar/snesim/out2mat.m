clear all,close all

N = 40000;
nx = 80;
ny = 40;
ng = nx*ny;

fidi = fopen('snesim.out');
data = textscan(fidi, '%f', 'HeaderLines',4, 'Delimiter','', 'CollectOutput',1);
fclose(fidi);
data = cell2mat(data);
binary = nan(floor(size(data,1)/2),1);
for i = 1 : floor(size(data,1)/2)
    binary(i) = data(i*2-1);
end

binary = binary(:,1);
K = zeros(N,ny,nx);
for i = 1 : N
    n1 = 1+ng*(i-1);
    n2 = i*ng;
    k = binary(n1:n2);
    K(i,:,:) = ( reshape(k,nx,ny) )';
end
save K.mat K

figure
for t = 1 : 12
    subplot(4,3,t),
    %contourf(squeeze(K(t,:,:)),40,'linestyle','none'),colorbar
    imagesc(squeeze(K(t,:,:))),colorbar
    hold on,
    
end

